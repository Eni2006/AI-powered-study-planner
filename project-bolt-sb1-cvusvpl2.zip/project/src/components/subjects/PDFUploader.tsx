import React, { useState, useRef } from 'react';
import { Upload, X, FileText, Loader2 } from 'lucide-react';
import * as pdfjsLib from 'pdfjs-dist';

pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

interface PDFUploaderProps {
  onUpload: (file: File, pageCount: number) => void;
  onError: (error: string) => void;
}

const PDFUploader: React.FC<PDFUploaderProps> = ({ onUpload, onError }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const validateAndProcessPDF = async (file: File) => {
    if (!file.type.includes('pdf')) {
      onError('Please upload a PDF file');
      return;
    }

    if (file.size > 50 * 1024 * 1024) {
      onError('File size should be less than 50MB');
      return;
    }

    setIsLoading(true);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      const pageCount = pdf.numPages;

      setSelectedFile(file);
      onUpload(file, pageCount);
    } catch (error) {
      onError('Error processing PDF. Please try another file.');
      setSelectedFile(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const file = e.dataTransfer.files[0];
    if (file) {
      await validateAndProcessPDF(file);
    }
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      await validateAndProcessPDF(file);
    }
  };

  const handleRemoveFile = () => {
    setSelectedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="w-full">
      {!selectedFile ? (
        <div
          className={`border-2 border-dashed rounded-lg p-6 transition-colors ${
            isDragging
              ? 'border-blue-500 bg-blue-50'
              : 'border-gray-300 hover:border-blue-400'
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <div className="flex flex-col items-center justify-center">
            <Upload
              size={32}
              className={`mb-3 ${
                isDragging ? 'text-blue-500' : 'text-gray-400'
              }`}
            />
            <p className="mb-2 text-sm font-medium text-gray-700">
              Drag and drop your PDF here, or{' '}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="text-blue-600 hover:text-blue-700 focus:outline-none focus:underline"
              >
                browse
              </button>
            </p>
            <p className="text-xs text-gray-500">PDF files up to 50MB</p>
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf"
              onChange={handleFileSelect}
              className="hidden"
            />
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center">
            <FileText size={24} className="text-blue-600 mr-3" />
            <div>
              <p className="text-sm font-medium text-gray-700">
                {selectedFile.name}
              </p>
              <p className="text-xs text-gray-500">
                {(selectedFile.size / (1024 * 1024)).toFixed(2)} MB
              </p>
            </div>
          </div>
          <button
            onClick={handleRemoveFile}
            className="p-1 hover:bg-gray-200 rounded-full transition-colors"
          >
            <X size={16} className="text-gray-500" />
          </button>
        </div>
      )}

      {isLoading && (
        <div className="flex items-center justify-center mt-4">
          <Loader2 size={20} className="animate-spin text-blue-600 mr-2" />
          <span className="text-sm text-gray-600">Processing PDF...</span>
        </div>
      )}
    </div>
  );
};

export default PDFUploader;