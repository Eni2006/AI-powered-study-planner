import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Volume2, VolumeX } from 'lucide-react';

interface TimerProps {
  initialMinutes?: number;
  initialSeconds?: number;
  onComplete?: () => void;
}

const Timer: React.FC<TimerProps> = ({ 
  initialMinutes = 25, 
  initialSeconds = 0,
  onComplete 
}) => {
  const [minutes, setMinutes] = useState(initialMinutes);
  const [seconds, setSeconds] = useState(initialSeconds);
  const [isActive, setIsActive] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [mode, setMode] = useState<'focus' | 'break'>('focus');
  const [progress, setProgress] = useState(100);
  
  // Total time in seconds (for progress calculation)
  const totalSeconds = React.useMemo(() => initialMinutes * 60 + initialSeconds, [initialMinutes, initialSeconds]);
  
  // Reset timer
  const reset = () => {
    setMinutes(initialMinutes);
    setSeconds(initialSeconds);
    setIsActive(false);
    setProgress(100);
  };
  
  // Toggle timer active state
  const toggle = () => {
    setIsActive(!isActive);
  };
  
  // Toggle sound
  const toggleSound = () => {
    setIsMuted(!isMuted);
  };
  
  // Switch between focus and break modes
  const switchMode = () => {
    if (mode === 'focus') {
      // Switch to break mode (5 minutes)
      setMinutes(5);
      setSeconds(0);
      setMode('break');
    } else {
      // Switch back to focus mode
      setMinutes(initialMinutes);
      setSeconds(initialSeconds);
      setMode('focus');
    }
    setIsActive(false);
    setProgress(100);
  };
  
  // Timer logic
  useEffect(() => {
    let interval: number | null = null;
    
    if (isActive) {
      interval = window.setInterval(() => {
        if (seconds === 0) {
          if (minutes === 0) {
            // Timer complete
            clearInterval(interval!);
            setIsActive(false);
            
            // Play sound if not muted
            if (!isMuted) {
              const audio = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-software-interface-alert-notification-256.mp3');
              audio.play();
            }
            
            // Call onComplete callback if provided
            if (onComplete) {
              onComplete();
            }
            
            return;
          }
          
          // Decrement minutes and reset seconds
          setMinutes(minutes - 1);
          setSeconds(59);
        } else {
          // Decrement seconds
          setSeconds(seconds - 1);
        }
        
        // Calculate progress
        const currentTotalSeconds = minutes * 60 + seconds;
        const remainingPercentage = (currentTotalSeconds / totalSeconds) * 100;
        setProgress(remainingPercentage);
      }, 1000);
    } else if (interval) {
      clearInterval(interval);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isActive, minutes, seconds, isMuted, onComplete, totalSeconds]);

  return (
    <div className={`rounded-xl shadow-md p-6 transition-all ${
      mode === 'focus' ? 'bg-blue-50' : 'bg-green-50'
    }`}>
      <div className="flex justify-between items-center mb-4">
        <h3 className={`text-lg font-bold ${
          mode === 'focus' ? 'text-blue-900' : 'text-green-900'
        }`}>
          {mode === 'focus' ? 'Focus Time' : 'Break Time'}
        </h3>
        <button 
          onClick={toggleSound}
          className="p-2 rounded-full hover:bg-white/50 transition-colors"
        >
          {isMuted ? (
            <VolumeX size={18} className="text-gray-500" />
          ) : (
            <Volume2 size={18} className="text-gray-500" />
          )}
        </button>
      </div>
      
      {/* Timer display */}
      <div className="relative w-48 h-48 mx-auto mb-6">
        {/* Progress circle */}
        <svg className="w-full h-full" viewBox="0 0 100 100">
          {/* Background circle */}
          <circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke={mode === 'focus' ? '#E6F0FF' : '#E6FFF0'}
            strokeWidth="8"
          />
          
          {/* Progress circle */}
          <circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke={mode === 'focus' ? '#3B82F6' : '#10B981'}
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray="283"
            strokeDashoffset={283 - (283 * progress) / 100}
            transform="rotate(-90 50 50)"
          />
        </svg>
        
        {/* Time display */}
        <div className="absolute inset-0 flex items-center justify-center">
          <span className={`text-4xl font-bold ${
            mode === 'focus' ? 'text-blue-900' : 'text-green-900'
          }`}>
            {minutes.toString().padStart(2, '0')}:{seconds.toString().padStart(2, '0')}
          </span>
        </div>
      </div>
      
      {/* Control buttons */}
      <div className="flex justify-center space-x-4">
        <button
          onClick={toggle}
          className={`p-3 rounded-full ${
            mode === 'focus' 
              ? 'bg-blue-100 text-blue-700 hover:bg-blue-200' 
              : 'bg-green-100 text-green-700 hover:bg-green-200'
          } transition-colors`}
        >
          {isActive ? <Pause size={24} /> : <Play size={24} />}
        </button>
        
        <button
          onClick={reset}
          className="p-3 rounded-full bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors"
        >
          <RotateCcw size={24} />
        </button>
      </div>
      
      {/* Mode switch button */}
      <button
        onClick={switchMode}
        className={`mt-4 w-full py-2 rounded-lg text-sm font-medium transition-colors ${
          mode === 'focus'
            ? 'bg-green-100 text-green-700 hover:bg-green-200'
            : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
        }`}
      >
        Switch to {mode === 'focus' ? 'Break' : 'Focus'} Mode
      </button>
    </div>
  );
};

export default Timer;