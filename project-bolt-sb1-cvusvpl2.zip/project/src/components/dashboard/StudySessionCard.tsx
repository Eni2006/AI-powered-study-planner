import React from 'react';
import { Clock, Calendar } from 'lucide-react';
import { Subject, StudySession } from '../../types';

interface StudySessionCardProps {
  session: StudySession;
  subject: Subject;
  onComplete: () => void;
}

const StudySessionCard: React.FC<StudySessionCardProps> = ({ session, subject, onComplete }) => {
  const formatTime = (date: Date): string => {
    return new Date(date).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const formatDate = (date: Date): string => {
    const today = new Date();
    const sessionDate = new Date(date);
    
    // Check if same day
    if (
      sessionDate.getDate() === today.getDate() &&
      sessionDate.getMonth() === today.getMonth() &&
      sessionDate.getFullYear() === today.getFullYear()
    ) {
      return 'Today';
    }
    
    // Check if tomorrow
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    if (
      sessionDate.getDate() === tomorrow.getDate() &&
      sessionDate.getMonth() === tomorrow.getMonth() &&
      sessionDate.getFullYear() === tomorrow.getFullYear()
    ) {
      return 'Tomorrow';
    }
    
    // Otherwise format as date
    return sessionDate.toLocaleDateString('en-US', { 
      weekday: 'short',
      month: 'short', 
      day: 'numeric'
    });
  };

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100 transition-all hover:shadow-md">
      <div className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div 
            className="text-xs font-semibold px-2.5 py-0.5 rounded-full"
            style={{ 
              backgroundColor: `${subject.color}20`, 
              color: subject.color 
            }}
          >
            {subject.name}
          </div>
          
          <div className="text-xs text-gray-500 flex items-center">
            <Clock size={12} className="mr-1" />
            {session.duration} min
          </div>
        </div>
        
        <div className="flex items-center text-gray-700 mb-3">
          <Calendar size={14} className="mr-1.5" />
          <span className="text-sm">
            {formatDate(session.date)}, {formatTime(session.date)}
          </span>
        </div>
        
        {session.notes && (
          <p className="text-sm text-gray-600 mt-2 mb-3">{session.notes}</p>
        )}
        
        {session.completed ? (
          <div className="flex items-center justify-center rounded-lg bg-green-50 text-green-700 py-2 text-sm font-medium">
            Completed ✓
          </div>
        ) : (
          <button 
            onClick={onComplete}
            className="w-full flex items-center justify-center rounded-lg bg-blue-50 text-blue-700 
              py-2 text-sm font-medium hover:bg-blue-100 transition-colors"
          >
            Start Session
          </button>
        )}
      </div>
    </div>
  );
};

export default StudySessionCard;