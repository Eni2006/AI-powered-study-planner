import React from 'react';
import { Clock, TrendingUp, Award } from 'lucide-react';
import { StudyStats } from '../../types';

interface StudyStatsCardProps {
  stats: StudyStats;
}

const StudyStatsCard: React.FC<StudyStatsCardProps> = ({ stats }) => {
  // Format minutes into hours and minutes
  const formatStudyTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    
    if (hours === 0) {
      return `${mins} min`;
    }
    
    return `${hours}h ${mins}m`;
  };

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden">
      <div className="p-6">
        <h3 className="text-lg font-bold text-gray-800 mb-4">Study Progress</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Total study time */}
          <div className="bg-blue-50 rounded-lg p-4 flex items-center">
            <div className="bg-blue-100 p-2 rounded-full mr-4">
              <Clock size={20} className="text-blue-600" />
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-600">Total Time</h4>
              <p className="text-lg font-bold text-gray-900">{formatStudyTime(stats.totalStudyTime)}</p>
            </div>
          </div>
          
          {/* Sessions completed */}
          <div className="bg-green-50 rounded-lg p-4 flex items-center">
            <div className="bg-green-100 p-2 rounded-full mr-4">
              <Award size={20} className="text-green-600" />
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-600">Sessions</h4>
              <p className="text-lg font-bold text-gray-900">{stats.sessionsCompleted}</p>
            </div>
          </div>
          
          {/* Weekly trend */}
          <div className="bg-purple-50 rounded-lg p-4 flex items-center">
            <div className="bg-purple-100 p-2 rounded-full mr-4">
              <TrendingUp size={20} className="text-purple-600" />
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-600">Weekly Avg</h4>
              <p className="text-lg font-bold text-gray-900">
                {formatStudyTime(
                  Math.round(
                    Object.values(stats.weeklyProgress).reduce((sum, val) => sum + val, 0) / 
                    Math.max(1, Object.keys(stats.weeklyProgress).length)
                  )
                )}
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Mini progress chart at the bottom */}
      <div className="px-6 pt-0 pb-4">
        <div className="flex items-center justify-between mb-2">
          <h4 className="text-sm font-medium text-gray-600">Last 7 Days</h4>
        </div>
        <div className="flex h-16 items-end space-x-1">
          {Array.from({ length: 7 }).map((_, i) => {
            // Random height for demo purposes (would use actual data)
            const height = 20 + Math.floor(Math.random() * 60);
            const today = i === 6;
            
            return (
              <div key={i} className="flex-1 flex flex-col items-center">
                <div 
                  className={`w-full rounded-t transition-all ${today ? 'bg-blue-500' : 'bg-blue-200'}`} 
                  style={{ height: `${height}%` }}
                ></div>
                <span className="text-xs text-gray-400 mt-1">
                  {["M", "T", "W", "T", "F", "S", "S"][i]}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default StudyStatsCard;