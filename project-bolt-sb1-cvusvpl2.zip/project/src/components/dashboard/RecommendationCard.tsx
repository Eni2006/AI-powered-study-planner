import React from 'react';
import { Lightbulb } from 'lucide-react';

interface RecommendationCardProps {
  recommendations: string[];
}

const RecommendationCard: React.FC<RecommendationCardProps> = ({ recommendations }) => {
  return (
    <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl shadow-lg text-white p-6 transition-all hover:shadow-xl">
      <div className="flex items-center mb-4">
        <div className="bg-white/20 p-2 rounded-lg mr-3">
          <Lightbulb size={24} className="text-white" />
        </div>
        <h3 className="text-xl font-bold">AI Recommendations</h3>
      </div>
      
      <div className="space-y-3">
        {recommendations.length > 0 ? (
          recommendations.map((recommendation, index) => (
            <div key={index} className="flex items-start">
              <div className="text-yellow-300 mr-2 mt-1">•</div>
              <p>{recommendation}</p>
            </div>
          ))
        ) : (
          <p>Complete more study sessions to receive personalized recommendations.</p>
        )}
      </div>
      
      <button className="mt-4 w-full bg-white/10 hover:bg-white/20 border border-white/30 rounded-lg py-2 px-4 text-white font-medium transition-colors">
        Generate New Insights
      </button>
    </div>
  );
};

export default RecommendationCard;