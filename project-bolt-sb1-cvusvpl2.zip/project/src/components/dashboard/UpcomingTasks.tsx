import React from 'react';
import { Task } from '../../types';
import { Clock, CheckCircle2 } from 'lucide-react';

interface UpcomingTasksProps {
  tasks: Task[];
  onToggleComplete: (id: string) => void;
}

const UpcomingTasks: React.FC<UpcomingTasksProps> = ({ tasks, onToggleComplete }) => {
  // Get only incomplete tasks and sort by due date (closest first)
  const sortedTasks = [...tasks]
    .filter(task => !task.completed)
    .sort((a, b) => {
      // Sort by priority first (high to low)
      if (a.priority !== b.priority) {
        return b.priority - a.priority;
      }
      
      // Then by due date (if exists)
      const aDate = a.dueDate ? a.dueDate.getTime() : Infinity;
      const bDate = b.dueDate ? b.dueDate.getTime() : Infinity;
      return aDate - bDate;
    })
    .slice(0, 5); // Only show top 5 tasks
  
  // Format date to display
  const formatDate = (date?: Date): string => {
    if (!date) return 'No due date';
    
    const now = new Date();
    const taskDate = new Date(date);
    
    // Check if same day
    if (
      taskDate.getDate() === now.getDate() &&
      taskDate.getMonth() === now.getMonth() &&
      taskDate.getFullYear() === now.getFullYear()
    ) {
      return 'Today';
    }
    
    // Check if tomorrow
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    if (
      taskDate.getDate() === tomorrow.getDate() &&
      taskDate.getMonth() === tomorrow.getMonth() &&
      taskDate.getFullYear() === tomorrow.getFullYear()
    ) {
      return 'Tomorrow';
    }
    
    // Otherwise format as date
    return taskDate.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: taskDate.getFullYear() !== now.getFullYear() ? 'numeric' : undefined
    });
  };
  
  // Get priority label and color
  const getPriorityInfo = (priority: number) => {
    switch(priority) {
      case 3:
        return { label: 'High', color: 'bg-red-100 text-red-800' };
      case 2:
        return { label: 'Medium', color: 'bg-yellow-100 text-yellow-800' };
      case 1:
      default:
        return { label: 'Low', color: 'bg-green-100 text-green-800' };
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
        <Clock size={18} className="mr-2 text-blue-600" />
        Upcoming Tasks
      </h3>
      
      {sortedTasks.length > 0 ? (
        <ul className="divide-y divide-gray-100">
          {sortedTasks.map(task => {
            const { label, color } = getPriorityInfo(task.priority);
            
            return (
              <li key={task.id} className="py-3 flex items-start justify-between group">
                <div className="flex-1 mr-4">
                  <div className="flex items-center">
                    <button 
                      onClick={() => onToggleComplete(task.id)}
                      className="h-5 w-5 rounded-full border-2 border-gray-300 flex-shrink-0 mr-3 
                        group-hover:border-blue-500 transition-colors"
                    >
                      <CheckCircle2 
                        size={16} 
                        className="text-white opacity-0 group-hover:opacity-30" 
                      />
                    </button>
                    <span className="font-medium text-gray-800">{task.title}</span>
                  </div>
                  
                  {task.description && (
                    <p className="text-sm text-gray-500 mt-1 ml-8">{task.description}</p>
                  )}
                  
                  <div className="flex items-center mt-2 ml-8">
                    <span className={`text-xs px-2 py-1 rounded-full ${color}`}>
                      {label}
                    </span>
                    
                    {task.estimatedTime && (
                      <span className="text-xs text-gray-500 ml-2">
                        {task.estimatedTime} min
                      </span>
                    )}
                    
                    {task.dueDate && (
                      <span className="text-xs ml-2 text-gray-500">
                        Due: {formatDate(task.dueDate)}
                      </span>
                    )}
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      ) : (
        <div className="text-center py-6 text-gray-500">
          <p>No upcoming tasks</p>
          <button className="mt-2 text-blue-600 hover:text-blue-800 text-sm font-medium">
            + Add new task
          </button>
        </div>
      )}
      
      {sortedTasks.length > 0 && (
        <button className="mt-3 text-blue-600 hover:text-blue-800 text-sm font-medium">
          View all tasks
        </button>
      )}
    </div>
  );
};

export default UpcomingTasks;