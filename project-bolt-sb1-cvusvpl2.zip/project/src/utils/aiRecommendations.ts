import { Subject, Task, StudySession, UserPreferences } from '../types';

// This is a simplified mock of what would typically be an API call to an AI service
export const generateStudyPlan = (
  subjects: Subject[],
  tasks: Task[],
  preferences: UserPreferences
): StudySession[] => {
  const newSessions: StudySession[] = [];
  const now = new Date();
  
  // Get active subjects (those with incomplete tasks)
  const activeSubjectIds = [...new Set(
    tasks.filter(task => !task.completed).map(task => task.subjectId)
  )];
  
  if (activeSubjectIds.length === 0) return [];
  
  // Create a priority score for each subject based on difficulty, priority, and due dates of associated tasks
  const subjectScores = activeSubjectIds.map(subjectId => {
    const subject = subjects.find(s => s.id === subjectId);
    if (!subject) return { subjectId, score: 0 };
    
    const subjectTasks = tasks.filter(t => t.subjectId === subjectId && !t.completed);
    
    // Calculate average priority and find closest due date
    const avgPriority = subjectTasks.reduce((sum, t) => sum + t.priority, 0) / subjectTasks.length;
    const closestDueDate = subjectTasks.reduce((closest, t) => {
      if (!t.dueDate) return closest;
      if (!closest) return t.dueDate;
      return t.dueDate < closest ? t.dueDate : closest;
    }, null as Date | null);
    
    // Calculate days until due
    const daysUntilDue = closestDueDate 
      ? Math.max(0, Math.floor((closestDueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)))
      : 7; // Default to a week if no due date
    
    // Score formula: higher for difficult subjects with high priority and close due dates
    const score = (subject.difficulty * 0.4) + (avgPriority * 0.3) + (7 - Math.min(daysUntilDue, 7)) * 0.3;
    
    return { subjectId, score };
  }).sort((a, b) => b.score - a.score);
  
  // Determine best study time based on preferences
  const getStudyHour = () => {
    switch (preferences.preferredStudyTime) {
      case 'morning': return 9; // 9 AM
      case 'afternoon': return 14; // 2 PM
      case 'evening': return 18; // 6 PM
      case 'night': return 20; // 8 PM
    }
  };
  
  // Generate 7 days of study sessions
  for (let day = 0; day < 7; day++) {
    // Distribute daily study goal among top subjects
    let remainingMinutes = preferences.dailyStudyGoal;
    let sessionIndex = 0;
    
    while (remainingMinutes > 0 && sessionIndex < subjectScores.length) {
      const { subjectId } = subjectScores[sessionIndex % subjectScores.length];
      const subject = subjects.find(s => s.id === subjectId);
      
      // Skip if subject not found
      if (!subject) {
        sessionIndex++;
        continue;
      }
      
      // Calculate session duration based on subject difficulty
      // More difficult subjects get longer sessions but not exceeding remaining time
      const baseDuration = Math.min(30 + (subject.difficulty * 10), remainingMinutes);
      const duration = Math.floor(baseDuration / 5) * 5; // Round to nearest 5 minutes
      
      // Create date for the session
      const studyHour = getStudyHour();
      const sessionDate = new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate() + day,
        studyHour + Math.floor(sessionIndex / subjectScores.length) * 2, // Spread throughout the day
        0 // Start at the beginning of the hour
      );
      
      // Create new study session
      newSessions.push({
        id: crypto.randomUUID(),
        subjectId,
        date: sessionDate,
        duration,
        completed: false,
        notes: `AI recommended session for ${subject.name}`,
      });
      
      remainingMinutes -= duration;
      sessionIndex++;
    }
  }
  
  return newSessions;
};

// Function to get AI-recommended tasks to complete for a specific subject
export const getRecommendedTasksForSubject = (
  subjectId: string,
  tasks: Task[],
  studySessions: StudySession[]
): Task[] => {
  // Get incomplete tasks for this subject
  const incompleteTasks = tasks.filter(t => 
    t.subjectId === subjectId && !t.completed
  );
  
  if (incompleteTasks.length === 0) return [];
  
  // Sort tasks by a combination of:
  // 1. Priority (highest first)
  // 2. Due date (soonest first)
  // 3. Estimated time (quickest first for equal priority/due date)
  return incompleteTasks.sort((a, b) => {
    // First sort by priority
    if (a.priority !== b.priority) {
      return b.priority - a.priority;
    }
    
    // Then by due date
    const aDate = a.dueDate ? a.dueDate.getTime() : Infinity;
    const bDate = b.dueDate ? b.dueDate.getTime() : Infinity;
    if (aDate !== bDate) {
      return aDate - bDate;
    }
    
    // Finally by estimated time (shorter tasks first)
    const aTime = a.estimatedTime || Infinity;
    const bTime = b.estimatedTime || Infinity;
    return aTime - bTime;
  });
};

// Function to analyze study patterns and make recommendations
export const analyzeStudyPatterns = (
  studySessions: StudySession[],
  subjects: Subject[]
): string[] => {
  if (studySessions.length < 5) {
    return ["Not enough study data to analyze patterns. Complete more study sessions for personalized recommendations."];
  }
  
  const completedSessions = studySessions.filter(s => s.completed);
  const recommendations: string[] = [];
  
  // 1. Analyze time of day patterns
  const sessionHours = completedSessions.map(s => new Date(s.date).getHours());
  const hourCounts: Record<number, number> = {};
  sessionHours.forEach(hour => {
    hourCounts[hour] = (hourCounts[hour] || 0) + 1;
  });
  
  const bestHours = Object.entries(hourCounts)
    .sort((a, b) => Number(b[1]) - Number(a[1]))
    .slice(0, 2)
    .map(([hour]) => Number(hour));
  
  if (bestHours.length > 0) {
    const formatHour = (hour: number) => {
      return hour >= 12 
        ? `${hour === 12 ? 12 : hour - 12} PM` 
        : `${hour === 0 ? 12 : hour} AM`;
    };
    recommendations.push(
      `You seem most productive when studying around ${bestHours.map(formatHour).join(' and ')}.`
    );
  }
  
  // 2. Analyze subject coverage
  const subjectCoverage: Record<string, number> = {};
  completedSessions.forEach(s => {
    subjectCoverage[s.subjectId] = (subjectCoverage[s.subjectId] || 0) + s.duration;
  });
  
  const totalTime = Object.values(subjectCoverage).reduce((sum, time) => sum + time, 0);
  const neglectedSubjects = subjects.filter(s => {
    const coverage = subjectCoverage[s.id] || 0;
    return (coverage / totalTime < 0.1) && s.priority > 1;
  });
  
  if (neglectedSubjects.length > 0) {
    recommendations.push(
      `Consider allocating more time to ${neglectedSubjects.map(s => s.name).join(', ')}.`
    );
  }
  
  // 3. Analyze session duration effectiveness
  const sessionDurations = completedSessions.map(s => s.duration);
  const avgDuration = sessionDurations.reduce((sum, d) => sum + d, 0) / sessionDurations.length;
  
  if (avgDuration < 30) {
    recommendations.push(
      "Your study sessions seem quite short. Consider longer, focused sessions for better knowledge retention."
    );
  } else if (avgDuration > 120) {
    recommendations.push(
      "Your study sessions are quite long. Consider breaking them into smaller chunks with breaks to maintain focus."
    );
  }
  
  // Add default recommendation if we don't have enough insights
  if (recommendations.length === 0) {
    recommendations.push(
      "Keep up your consistent study habits. Try experimenting with different study times and session lengths to find your optimal pattern."
    );
  }
  
  return recommendations;
};