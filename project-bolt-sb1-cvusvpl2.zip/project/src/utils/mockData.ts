import { Subject, Task, StudySession, UserPreferences, StudyStats } from '../types';

export const generateMockData = () => {
  // Generate mock subjects
  const subjects: Subject[] = [
    { id: crypto.randomUUID(), name: 'Mathematics', color: '#3B82F6', difficulty: 4, priority: 3 },
    { id: crypto.randomUUID(), name: 'Computer Science', color: '#10B981', difficulty: 3, priority: 3 },
    { id: crypto.randomUUID(), name: 'Physics', color: '#F59E0B', difficulty: 5, priority: 2 },
    { id: crypto.randomUUID(), name: 'History', color: '#8B5CF6', difficulty: 2, priority: 1 },
  ];

  // Generate mock tasks
  const tasks: Task[] = [
    {
      id: crypto.randomUUID(),
      title: 'Calculus Problem Set',
      description: 'Complete problems 1-10 from Chapter 3',
      completed: false,
      subjectId: subjects[0].id,
      dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // 2 days from now
      estimatedTime: 60,
      priority: 3,
    },
    {
      id: crypto.randomUUID(),
      title: 'Algorithm Analysis',
      description: 'Study time complexity and space complexity',
      completed: false,
      subjectId: subjects[1].id,
      dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
      estimatedTime: 90,
      priority: 2,
    },
    {
      id: crypto.randomUUID(),
      title: 'Quantum Mechanics Notes',
      description: 'Review lecture notes on quantum principles',
      completed: true,
      subjectId: subjects[2].id,
      dueDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 day ago
      estimatedTime: 120,
      priority: 2,
    },
    {
      id: crypto.randomUUID(),
      title: 'Medieval Europe Essay',
      description: 'Write a 2-page essay on the impact of Black Death',
      completed: false,
      subjectId: subjects[3].id,
      dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
      estimatedTime: 180,
      priority: 3,
    },
  ];

  // Generate mock study sessions
  const now = new Date();
  const studySessions: StudySession[] = [
    {
      id: crypto.randomUUID(),
      subjectId: subjects[0].id,
      date: new Date(now.getFullYear(), now.getMonth(), now.getDate() - 3, 10, 0), // 3 days ago, 10:00 AM
      duration: 60, // 60 minutes
      completed: true,
      notes: 'Covered derivatives and integrals',
    },
    {
      id: crypto.randomUUID(),
      subjectId: subjects[1].id,
      date: new Date(now.getFullYear(), now.getMonth(), now.getDate() - 2, 14, 0), // 2 days ago, 2:00 PM
      duration: 90, // 90 minutes
      completed: true,
      notes: 'Studied data structures',
    },
    {
      id: crypto.randomUUID(),
      subjectId: subjects[2].id,
      date: new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1, 16, 0), // Yesterday, 4:00 PM
      duration: 120, // 120 minutes
      completed: true,
      notes: 'Worked on problems related to relativity',
    },
    {
      id: crypto.randomUUID(),
      subjectId: subjects[0].id,
      date: new Date(now.getFullYear(), now.getMonth(), now.getDate(), 9, 0), // Today, 9:00 AM
      duration: 75, // 75 minutes
      completed: true,
      notes: 'Practiced trigonometric integrals',
    },
    {
      id: crypto.randomUUID(),
      subjectId: subjects[3].id,
      date: new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 13, 0), // Tomorrow, 1:00 PM
      duration: 60, // 60 minutes
      completed: false,
      notes: 'Plan to review Renaissance period',
    },
  ];

  // Generate mock user preferences
  const userPreferences: UserPreferences = {
    dailyStudyGoal: 180, // 3 hours
    preferredStudyTime: 'morning',
    breakFrequency: 25, // Pomodoro technique: 25 minutes of study
    breakDuration: 5, // 5 minutes break
    notifications: true,
  };

  // Generate mock stats
  const stats: StudyStats = {
    totalStudyTime: 345, // Total minutes studied
    sessionsCompleted: 4,
    subjectBreakdown: {
      [subjects[0].id]: 135,
      [subjects[1].id]: 90,
      [subjects[2].id]: 120,
      [subjects[3].id]: 0,
    },
    weeklyProgress: {
      [`${now.getFullYear()}-W${Math.floor(now.getDate() / 7)}`]: 345,
    },
  };

  return {
    subjects,
    tasks,
    studySessions,
    userPreferences,
    stats,
  };
};