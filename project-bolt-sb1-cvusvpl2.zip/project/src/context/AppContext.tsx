import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Subject, Task, StudySession, UserPreferences, StudyStats } from '../types';
import { generateMockData } from '../utils/mockData';
import { generateStudyPlan } from '../utils/aiRecommendations';

interface AppContextType {
  subjects: Subject[];
  tasks: Task[];
  studySessions: StudySession[];
  userPreferences: UserPreferences;
  stats: StudyStats;
  activeView: 'dashboard' | 'calendar' | 'subjects' | 'tasks' | 'analytics' | 'settings';
  setActiveView: (view: 'dashboard' | 'calendar' | 'subjects' | 'tasks' | 'analytics' | 'settings') => void;
  addSubject: (subject: Omit<Subject, 'id'>) => void;
  updateSubject: (subject: Subject) => void;
  deleteSubject: (id: string) => void;
  addTask: (task: Omit<Task, 'id'>) => void;
  updateTask: (task: Task) => void;
  deleteTask: (id: string) => void;
  toggleTaskCompletion: (id: string) => void;
  addStudySession: (session: Omit<StudySession, 'id'>) => void;
  updateStudySession: (session: StudySession) => void;
  deleteStudySession: (id: string) => void;
  updateUserPreferences: (preferences: Partial<UserPreferences>) => void;
  generateSchedule: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Initialize with mock data for demo purposes
  const [mockData] = useState(generateMockData());
  const [subjects, setSubjects] = useState<Subject[]>(mockData.subjects);
  const [tasks, setTasks] = useState<Task[]>(mockData.tasks);
  const [studySessions, setStudySessions] = useState<StudySession[]>(mockData.studySessions);
  const [userPreferences, setUserPreferences] = useState<UserPreferences>(mockData.userPreferences);
  const [stats, setStats] = useState<StudyStats>(mockData.stats);
  const [activeView, setActiveView] = useState<'dashboard' | 'calendar' | 'subjects' | 'tasks' | 'analytics' | 'settings'>('dashboard');

  // Calculate stats whenever study sessions change
  useEffect(() => {
    calculateStats();
  }, [studySessions]);

  const calculateStats = () => {
    // Calculate total study time
    const totalStudyTime = studySessions.reduce((total, session) => {
      return session.completed ? total + session.duration : total;
    }, 0);

    // Calculate sessions completed
    const sessionsCompleted = studySessions.filter(session => session.completed).length;

    // Calculate subject breakdown
    const subjectBreakdown: Record<string, number> = {};
    studySessions.forEach(session => {
      if (session.completed) {
        subjectBreakdown[session.subjectId] = (subjectBreakdown[session.subjectId] || 0) + session.duration;
      }
    });

    // Calculate weekly progress
    const weeklyProgress: Record<string, number> = {};
    studySessions.forEach(session => {
      if (session.completed) {
        const date = new Date(session.date);
        const weekNumber = getWeekNumber(date);
        weeklyProgress[weekNumber] = (weeklyProgress[weekNumber] || 0) + session.duration;
      }
    });

    setStats({
      totalStudyTime,
      sessionsCompleted,
      subjectBreakdown,
      weeklyProgress,
    });
  };

  const getWeekNumber = (date: Date): string => {
    const d = new Date(date);
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() + 3 - (d.getDay() + 6) % 7);
    const week = Math.floor((d.getTime() - new Date(d.getFullYear(), 0, 4).getTime()) / 86400000 / 7);
    return `${d.getFullYear()}-W${week}`;
  };

  const addSubject = (subject: Omit<Subject, 'id'>) => {
    const newSubject = { ...subject, id: crypto.randomUUID() };
    setSubjects([...subjects, newSubject]);
  };

  const updateSubject = (subject: Subject) => {
    setSubjects(subjects.map(s => s.id === subject.id ? subject : s));
  };

  const deleteSubject = (id: string) => {
    setSubjects(subjects.filter(s => s.id !== id));
    // Remove related tasks and study sessions
    setTasks(tasks.filter(t => t.subjectId !== id));
    setStudySessions(studySessions.filter(s => s.subjectId !== id));
  };

  const addTask = (task: Omit<Task, 'id'>) => {
    const newTask = { ...task, id: crypto.randomUUID() };
    setTasks([...tasks, newTask]);
  };

  const updateTask = (task: Task) => {
    setTasks(tasks.map(t => t.id === task.id ? task : t));
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(t => t.id !== id));
  };

  const toggleTaskCompletion = (id: string) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const addStudySession = (session: Omit<StudySession, 'id'>) => {
    const newSession = { ...session, id: crypto.randomUUID() };
    setStudySessions([...studySessions, newSession]);
  };

  const updateStudySession = (session: StudySession) => {
    setStudySessions(studySessions.map(s => s.id === session.id ? session : s));
  };

  const deleteStudySession = (id: string) => {
    setStudySessions(studySessions.filter(s => s.id !== id));
  };

  const updateUserPreferences = (preferences: Partial<UserPreferences>) => {
    setUserPreferences({ ...userPreferences, ...preferences });
  };

  const generateSchedule = () => {
    const newSessions = generateStudyPlan(subjects, tasks, userPreferences);
    setStudySessions([...studySessions, ...newSessions]);
  };

  return (
    <AppContext.Provider value={{
      subjects,
      tasks,
      studySessions,
      userPreferences,
      stats,
      activeView,
      setActiveView,
      addSubject,
      updateSubject,
      deleteSubject,
      addTask,
      updateTask,
      deleteTask,
      toggleTaskCompletion,
      addStudySession,
      updateStudySession,
      deleteStudySession,
      updateUserPreferences,
      generateSchedule,
    }}>
      {children}
    </AppContext.Provider>
  );
};