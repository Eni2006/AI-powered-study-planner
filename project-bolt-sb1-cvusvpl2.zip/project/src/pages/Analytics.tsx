import React from 'react';
import { useAppContext } from '../context/AppContext';
import { BarChart2, PieChart, TrendingUp, Clock } from 'lucide-react';
import { analyzeStudyPatterns } from '../utils/aiRecommendations';

const Analytics: React.FC = () => {
  const { subjects, stats, studySessions } = useAppContext();
  
  // Format minutes into hours and minutes
  const formatStudyTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    
    if (hours === 0) {
      return `${mins} min`;
    }
    
    return `${hours}h ${mins > 0 ? `${mins}m` : ''}`;
  };
  
  // Get AI recommendations based on study patterns
  const recommendations = analyzeStudyPatterns(studySessions, subjects);
  
  // Get subject breakdown data for chart
  const subjectBreakdownData = Object.entries(stats.subjectBreakdown).map(([subjectId, time]) => {
    const subject = subjects.find(s => s.id === subjectId);
    return {
      id: subjectId,
      name: subject?.name || 'Unknown Subject',
      color: subject?.color || '#888888',
      time,
      percentage: Math.round((time / stats.totalStudyTime) * 100)
    };
  }).sort((a, b) => b.time - a.time);
  
  // Get weekly progress data for chart
  const weeklyProgressData = Object.entries(stats.weeklyProgress).map(([week, time]) => {
    // Extract week number from format YYYY-WXX
    const weekNumber = week.split('-W')[1];
    return {
      week: `Week ${weekNumber}`,
      time
    };
  }).sort((a, b) => a.week.localeCompare(b.week)).slice(-6); // Get last 6 weeks
  
  // Get study time distribution by day of week
  const studyTimeByDay = [0, 0, 0, 0, 0, 0, 0]; // Sun, Mon, ..., Sat
  
  studySessions.forEach(session => {
    if (session.completed) {
      const date = new Date(session.date);
      const dayOfWeek = date.getDay(); // 0 = Sunday, 1 = Monday, etc.
      studyTimeByDay[dayOfWeek] += session.duration;
    }
  });
  
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const studyTimeByDayData = studyTimeByDay.map((time, index) => ({
    day: dayNames[index],
    time
  }));
  
  // Get study sessions count by hour of day (for heat map)
  const studySessionsByHour: number[] = Array(24).fill(0);
  
  studySessions.forEach(session => {
    if (session.completed) {
      const date = new Date(session.date);
      const hour = date.getHours();
      studySessionsByHour[hour]++;
    }
  });
  
  // Find the max value for normalization
  const maxSessionsPerHour = Math.max(...studySessionsByHour);

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Study Analytics</h1>
      
      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center">
            <div className="bg-blue-100 p-3 rounded-full">
              <Clock size={24} className="text-blue-700" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-500">Total Study Time</h3>
              <p className="text-2xl font-bold text-gray-900">{formatStudyTime(stats.totalStudyTime)}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center">
            <div className="bg-green-100 p-3 rounded-full">
              <BarChart2 size={24} className="text-green-700" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-500">Study Sessions</h3>
              <p className="text-2xl font-bold text-gray-900">{stats.sessionsCompleted}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center">
            <div className="bg-purple-100 p-3 rounded-full">
              <TrendingUp size={24} className="text-purple-700" />
            </div>
            <div className="ml-4">
              <h3 className="text-sm font-medium text-gray-500">Avg. Daily Study</h3>
              <p className="text-2xl font-bold text-gray-900">
                {formatStudyTime(Math.round(stats.totalStudyTime / (stats.sessionsCompleted || 1)))}
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Subject Breakdown and Weekly Progress */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Subject Breakdown */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center mb-4">
            <PieChart size={20} className="text-blue-600 mr-2" />
            <h2 className="text-lg font-bold text-gray-800">Subject Breakdown</h2>
          </div>
          
          {subjectBreakdownData.length > 0 ? (
            <div>
              {/* Simplified Donut Chart */}
              <div className="relative w-48 h-48 mx-auto mb-6">
                <svg viewBox="0 0 100 100" className="w-full h-full">
                  {subjectBreakdownData.map((subject, index, arr) => {
                    let cumulativePercentage = 0;
                    for (let i = 0; i < index; i++) {
                      cumulativePercentage += arr[i].percentage;
                    }
                    
                    const startAngle = (cumulativePercentage / 100) * 360;
                    const endAngle = ((cumulativePercentage + subject.percentage) / 100) * 360;
                    
                    // Convert angles to radians for calculations
                    const startRad = (startAngle - 90) * (Math.PI / 180);
                    const endRad = (endAngle - 90) * (Math.PI / 180);
                    
                    // Calculate the points
                    const x1 = 50 + 40 * Math.cos(startRad);
                    const y1 = 50 + 40 * Math.sin(startRad);
                    const x2 = 50 + 40 * Math.cos(endRad);
                    const y2 = 50 + 40 * Math.sin(endRad);
                    
                    // Determine if arc should take long way around
                    const largeArcFlag = subject.percentage > 50 ? 1 : 0;
                    
                    // Create the path
                    const path = `
                      M 50 50
                      L ${x1} ${y1}
                      A 40 40 0 ${largeArcFlag} 1 ${x2} ${y2}
                      Z
                    `;
                    
                    return (
                      <path
                        key={subject.id}
                        d={path}
                        fill={subject.color}
                      />
                    );
                  })}
                  {/* Inner circle for donut effect */}
                  <circle cx="50" cy="50" r="25" fill="white" />
                </svg>
                
                {/* Center text */}
                <div className="absolute inset-0 flex items-center justify-center flex-col">
                  <span className="text-3xl font-bold text-gray-800">
                    {formatStudyTime(stats.totalStudyTime)}
                  </span>
                  <span className="text-xs text-gray-500">Total Time</span>
                </div>
              </div>
              
              {/* Legend */}
              <div className="space-y-2">
                {subjectBreakdownData.map(subject => (
                  <div key={subject.id} className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div 
                        className="w-3 h-3 rounded-full mr-2" 
                        style={{ backgroundColor: subject.color }}
                      ></div>
                      <span className="text-sm text-gray-700">{subject.name}</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-sm text-gray-500 mr-2">{formatStudyTime(subject.time)}</span>
                      <span className="text-xs text-gray-400 w-8 text-right">{subject.percentage}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>No study data available yet</p>
            </div>
          )}
        </div>
        
        {/* Weekly Progress */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center mb-4">
            <TrendingUp size={20} className="text-green-600 mr-2" />
            <h2 className="text-lg font-bold text-gray-800">Weekly Progress</h2>
          </div>
          
          {weeklyProgressData.length > 0 ? (
            <div className="h-64">
              {/* Simplified Bar Chart */}
              <div className="h-full flex items-end space-x-3">
                {weeklyProgressData.map((data, index) => {
                  const maxTime = Math.max(...weeklyProgressData.map(d => d.time));
                  const height = (data.time / maxTime) * 100;
                  
                  return (
                    <div key={index} className="flex-1 flex flex-col items-center">
                      <div className="w-full flex flex-col justify-end h-[80%]">
                        <div 
                          className="w-full bg-green-400 rounded-t transition-all"
                          style={{ height: `${height}%` }}
                        ></div>
                      </div>
                      <div className="mt-2 text-center">
                        <div className="text-xs text-gray-500">{data.week}</div>
                        <div className="text-xs font-medium">{formatStudyTime(data.time)}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>No weekly data available yet</p>
            </div>
          )}
        </div>
      </div>
      
      {/* Daily Study Patterns and Insights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Study Time by Day */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center mb-4">
            <BarChart2 size={20} className="text-blue-600 mr-2" />
            <h2 className="text-lg font-bold text-gray-800">Study Time by Day</h2>
          </div>
          
          {studyTimeByDayData.some(d => d.time > 0) ? (
            <div className="h-64">
              {/* Simplified Bar Chart */}
              <div className="h-full flex items-end space-x-1">
                {studyTimeByDayData.map((data, index) => {
                  const maxTime = Math.max(...studyTimeByDayData.map(d => d.time));
                  const height = maxTime === 0 ? 0 : (data.time / maxTime) * 100;
                  
                  // Highlight weekend
                  const isWeekend = index === 0 || index === 6;
                  
                  return (
                    <div key={index} className="flex-1 flex flex-col items-center">
                      <div className="w-full flex flex-col justify-end h-[80%]">
                        <div 
                          className={`w-full ${isWeekend ? 'bg-blue-300' : 'bg-blue-500'} rounded-t transition-all`}
                          style={{ height: `${height}%` }}
                        ></div>
                      </div>
                      <div className="mt-2 text-center">
                        <div className={`text-xs ${isWeekend ? 'font-medium' : 'text-gray-500'}`}>{data.day}</div>
                        <div className="text-xs font-medium">{formatStudyTime(data.time)}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>No daily study data available yet</p>
            </div>
          )}
        </div>
        
        {/* AI Insights */}
        <div className="bg-gradient-to-br from-blue-600 to-blue-700 text-white rounded-xl shadow-lg p-6">
          <div className="flex items-center mb-6">
            <div className="bg-white/20 p-2 rounded-lg mr-3">
              <PieChart size={24} className="text-white" />
            </div>
            <h2 className="text-xl font-bold">AI Study Insights</h2>
          </div>
          
          <div className="space-y-4">
            {recommendations.map((recommendation, index) => (
              <div key={index} className="flex items-start">
                <div className="text-yellow-300 mr-2 mt-1">•</div>
                <p>{recommendation}</p>
              </div>
            ))}
          </div>
          
          {/* Study Time Heatmap */}
          <div className="mt-6">
            <h3 className="text-sm font-medium mb-2 opacity-80">Study Time Heatmap</h3>
            <div className="flex justify-between items-center">
              {/* Morning (6AM-12PM) */}
              <div className="flex-1">
                <div className="text-xs opacity-70 mb-1">Morning</div>
                <div className="flex">
                  {[6, 7, 8, 9, 10, 11].map(hour => {
                    const intensity = maxSessionsPerHour === 0 
                      ? 0 
                      : studySessionsByHour[hour] / maxSessionsPerHour;
                    return (
                      <div
                        key={hour}
                        className="flex-1 h-4 rounded-sm mx-0.5"
                        style={{ 
                          backgroundColor: `rgba(255, 255, 255, ${Math.max(0.1, intensity)})`,
                          opacity: intensity > 0 ? 1 : 0.3
                        }}
                        title={`${hour}:00 - ${hour + 1}:00: ${studySessionsByHour[hour]} sessions`}
                      ></div>
                    );
                  })}
                </div>
              </div>
              
              {/* Afternoon (12PM-6PM) */}
              <div className="flex-1 mx-2">
                <div className="text-xs opacity-70 mb-1">Afternoon</div>
                <div className="flex">
                  {[12, 13, 14, 15, 16, 17].map(hour => {
                    const intensity = maxSessionsPerHour === 0 
                      ? 0 
                      : studySessionsByHour[hour] / maxSessionsPerHour;
                    return (
                      <div
                        key={hour}
                        className="flex-1 h-4 rounded-sm mx-0.5"
                        style={{ 
                          backgroundColor: `rgba(255, 255, 255, ${Math.max(0.1, intensity)})`,
                          opacity: intensity > 0 ? 1 : 0.3
                        }}
                        title={`${hour}:00 - ${hour + 1}:00: ${studySessionsByHour[hour]} sessions`}
                      ></div>
                    );
                  })}
                </div>
              </div>
              
              {/* Evening (6PM-12AM) */}
              <div className="flex-1">
                <div className="text-xs opacity-70 mb-1">Evening</div>
                <div className="flex">
                  {[18, 19, 20, 21, 22, 23].map(hour => {
                    const intensity = maxSessionsPerHour === 0 
                      ? 0 
                      : studySessionsByHour[hour] / maxSessionsPerHour;
                    return (
                      <div
                        key={hour}
                        className="flex-1 h-4 rounded-sm mx-0.5"
                        style={{ 
                          backgroundColor: `rgba(255, 255, 255, ${Math.max(0.1, intensity)})`,
                          opacity: intensity > 0 ? 1 : 0.3
                        }}
                        title={`${hour}:00 - ${hour + 1}:00: ${studySessionsByHour[hour]} sessions`}
                      ></div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;