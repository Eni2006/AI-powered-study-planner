import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { CheckCircle2, Clock, PlusCircle, Calendar, Pencil, Trash2 } from 'lucide-react';

const Tasks: React.FC = () => {
  const { tasks, subjects, addTask, updateTask, deleteTask, toggleTaskCompletion } = useAppContext();
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed'>('pending');
  const [subjectFilter, setSubjectFilter] = useState<string | 'all'>('all');
  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    completed: false,
    subjectId: '',
    estimatedTime: 30,
    priority: 2,
    dueDate: ''
  });

  // Format dates for display
  const formatDate = (date?: Date): string => {
    if (!date) return '';
    return new Date(date).toISOString().split('T')[0];
  };
  
  // Format date for readable display
  const formatDateReadable = (date?: Date): string => {
    if (!date) return 'No due date';
    
    const taskDate = new Date(date);
    return taskDate.toLocaleDateString('en-US', { 
      weekday: 'short',
      month: 'short', 
      day: 'numeric',
      year: taskDate.getFullYear() !== new Date().getFullYear() ? 'numeric' : undefined
    });
  };
  
  // Filter tasks based on selected filters
  const filteredTasks = tasks.filter(task => {
    // Filter by completion status
    if (filter === 'pending' && task.completed) return false;
    if (filter === 'completed' && !task.completed) return false;
    
    // Filter by subject
    if (subjectFilter !== 'all' && task.subjectId !== subjectFilter) return false;
    
    return true;
  });
  
  // Sort tasks by priority (high to low) and due date (earliest first)
  const sortedTasks = [...filteredTasks].sort((a, b) => {
    // First by completion status
    if (a.completed !== b.completed) {
      return a.completed ? 1 : -1;
    }
    
    // Then by priority
    if (a.priority !== b.priority) {
      return b.priority - a.priority;
    }
    
    // Finally by due date
    const aDate = a.dueDate ? new Date(a.dueDate).getTime() : Infinity;
    const bDate = b.dueDate ? new Date(b.dueDate).getTime() : Infinity;
    return aDate - bDate;
  });
  
  // Get priority label and color
  const getPriorityInfo = (priority: number) => {
    switch(priority) {
      case 3:
        return { label: 'High', color: 'bg-red-100 text-red-800 border-red-200' };
      case 2:
        return { label: 'Medium', color: 'bg-yellow-100 text-yellow-800 border-yellow-200' };
      case 1:
      default:
        return { label: 'Low', color: 'bg-green-100 text-green-800 border-green-200' };
    }
  };
  
  // Handle form submission for new/edited task
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const taskData = {
      ...newTask,
      dueDate: newTask.dueDate ? new Date(newTask.dueDate) : undefined,
      estimatedTime: Number(newTask.estimatedTime),
      priority: Number(newTask.priority)
    };
    
    if (isEditing) {
      updateTask({ id: isEditing, ...taskData });
      setIsEditing(null);
    } else {
      addTask(taskData);
      setIsAdding(false);
    }
    
    // Reset form
    setNewTask({
      title: '',
      description: '',
      completed: false,
      subjectId: '',
      estimatedTime: 30,
      priority: 2,
      dueDate: ''
    });
  };
  
  // Start editing a task
  const startEditing = (task: typeof tasks[0]) => {
    setNewTask({
      title: task.title,
      description: task.description || '',
      completed: task.completed,
      subjectId: task.subjectId,
      estimatedTime: task.estimatedTime || 30,
      priority: task.priority,
      dueDate: task.dueDate ? formatDate(task.dueDate) : ''
    });
    setIsEditing(task.id);
    setIsAdding(false);
  };
  
  // Handle task deletion
  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this task?')) {
      deleteTask(id);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Tasks</h1>
        
        {!isAdding && !isEditing && (
          <button 
            onClick={() => setIsAdding(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center"
          >
            <PlusCircle size={16} className="mr-1" />
            Add Task
          </button>
        )}
      </div>
      
      {/* Form for adding/editing task */}
      {(isAdding || isEditing) && (
        <div className="bg-white rounded-xl shadow-md p-6 mb-6">
          <h2 className="text-lg font-bold mb-4">
            {isEditing ? 'Edit Task' : 'Add New Task'}
          </h2>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                Task Title
              </label>
              <input
                type="text"
                id="title"
                value={newTask.title}
                onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>
            
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                Description (Optional)
              </label>
              <textarea
                id="description"
                value={newTask.description}
                onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                rows={3}
              />
            </div>
            
            <div>
              <label htmlFor="subjectId" className="block text-sm font-medium text-gray-700 mb-1">
                Subject
              </label>
              <select
                id="subjectId"
                value={newTask.subjectId}
                onChange={(e) => setNewTask({ ...newTask, subjectId: e.target.value })}
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                required
              >
                <option value="" disabled>Select a subject</option>
                {subjects.map(subject => (
                  <option key={subject.id} value={subject.id}>
                    {subject.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label htmlFor="dueDate" className="block text-sm font-medium text-gray-700 mb-1">
                  Due Date (Optional)
                </label>
                <input
                  type="date"
                  id="dueDate"
                  value={newTask.dueDate}
                  onChange={(e) => setNewTask({ ...newTask, dueDate: e.target.value })}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              
              <div>
                <label htmlFor="estimatedTime" className="block text-sm font-medium text-gray-700 mb-1">
                  Estimated Time (minutes)
                </label>
                <input
                  type="number"
                  id="estimatedTime"
                  min="5"
                  step="5"
                  value={newTask.estimatedTime}
                  onChange={(e) => setNewTask({ ...newTask, estimatedTime: parseInt(e.target.value) })}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              
              <div>
                <label htmlFor="priority" className="block text-sm font-medium text-gray-700 mb-1">
                  Priority
                </label>
                <select
                  id="priority"
                  value={newTask.priority}
                  onChange={(e) => setNewTask({ ...newTask, priority: parseInt(e.target.value) })}
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="1">Low</option>
                  <option value="2">Medium</option>
                  <option value="3">High</option>
                </select>
              </div>
            </div>
            
            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setIsAdding(false);
                  setIsEditing(null);
                  setNewTask({
                    title: '',
                    description: '',
                    completed: false,
                    subjectId: '',
                    estimatedTime: 30,
                    priority: 2,
                    dueDate: ''
                  });
                }}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
              >
                {isEditing ? 'Update' : 'Add'} Task
              </button>
            </div>
          </form>
        </div>
      )}
      
      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 flex">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 text-sm font-medium rounded-l-lg transition-colors ${
              filter === 'all' ? 'bg-blue-50 text-blue-700' : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('pending')}
            className={`px-3 py-1.5 text-sm font-medium transition-colors ${
              filter === 'pending' ? 'bg-blue-50 text-blue-700' : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            Pending
          </button>
          <button
            onClick={() => setFilter('completed')}
            className={`px-3 py-1.5 text-sm font-medium rounded-r-lg transition-colors ${
              filter === 'completed' ? 'bg-blue-50 text-blue-700' : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            Completed
          </button>
        </div>
        
        <div>
          <select
            value={subjectFilter}
            onChange={(e) => setSubjectFilter(e.target.value)}
            className="p-1.5 text-sm border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="all">All Subjects</option>
            {subjects.map(subject => (
              <option key={subject.id} value={subject.id}>
                {subject.name}
              </option>
            ))}
          </select>
        </div>
        
        <div className="text-sm text-gray-500 ml-auto">
          {sortedTasks.length} {sortedTasks.length === 1 ? 'task' : 'tasks'} found
        </div>
      </div>
      
      {/* Tasks list */}
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        {sortedTasks.length > 0 ? (
          <ul className="divide-y divide-gray-100">
            {sortedTasks.map(task => {
              const subject = subjects.find(s => s.id === task.subjectId);
              const { label, color } = getPriorityInfo(task.priority);
              
              return (
                <li 
                  key={task.id} 
                  className={`p-4 hover:bg-gray-50 transition-colors ${
                    task.completed ? 'bg-gray-50' : ''
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <button 
                      onClick={() => toggleTaskCompletion(task.id)}
                      className={`mt-0.5 flex-shrink-0 h-5 w-5 rounded-full border-2 ${
                        task.completed 
                          ? 'bg-blue-500 border-blue-500 flex items-center justify-center'
                          : 'border-gray-300 hover:border-blue-500'
                      } transition-colors`}
                    >
                      {task.completed && (
                        <CheckCircle2 size={14} className="text-white" />
                      )}
                    </button>
                    
                    <div className="flex-grow min-w-0">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className={`font-medium ${
                            task.completed ? 'text-gray-500 line-through' : 'text-gray-900'
                          }`}>
                            {task.title}
                          </h3>
                          
                          {task.description && (
                            <p className={`text-sm mt-1 ${
                              task.completed ? 'text-gray-400' : 'text-gray-600'
                            }`}>
                              {task.description}
                            </p>
                          )}
                        </div>
                        
                        <div className="flex items-center ml-4">
                          <button 
                            onClick={() => startEditing(task)}
                            className="p-1 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                          >
                            <Pencil size={14} />
                          </button>
                          <button 
                            onClick={() => handleDelete(task.id)}
                            className="p-1 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors ml-1"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                      
                      <div className="flex flex-wrap items-center gap-2 mt-2">
                        {/* Subject badge */}
                        {subject && (
                          <span
                            className="text-xs px-2 py-1 rounded-full"
                            style={{ 
                              backgroundColor: `${subject.color}15`, 
                              color: subject.color
                            }}
                          >
                            {subject.name}
                          </span>
                        )}
                        
                        {/* Priority badge */}
                        <span className={`text-xs px-2 py-1 rounded-full border ${color}`}>
                          {label} Priority
                        </span>
                        
                        {/* Estimated time */}
                        {task.estimatedTime && (
                          <span className="text-xs flex items-center text-gray-500">
                            <Clock size={12} className="mr-1" /> 
                            {task.estimatedTime} min
                          </span>
                        )}
                        
                        {/* Due date */}
                        {task.dueDate && (
                          <span className="text-xs flex items-center text-gray-500">
                            <Calendar size={12} className="mr-1" /> 
                            {formatDateReadable(task.dueDate)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        ) : (
          <div className="p-8 text-center">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gray-100 text-gray-400 mb-3">
              <CheckCircle2 size={24} />
            </div>
            <h3 className="text-lg font-medium text-gray-800 mb-2">No Tasks Found</h3>
            <p className="text-gray-500 mb-4">
              {filter === 'completed' 
                ? "You haven't completed any tasks yet."
                : subjectFilter !== 'all'
                  ? "No tasks found for the selected subject."
                  : "Add your first task to start organizing your studies."
              }
            </p>
            {filter !== 'completed' && (
              <button 
                onClick={() => setIsAdding(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                <PlusCircle size={16} className="inline mr-1" />
                Add Task
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Tasks;