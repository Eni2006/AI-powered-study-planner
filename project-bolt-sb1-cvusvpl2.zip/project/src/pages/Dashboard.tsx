import React from 'react';
import { useAppContext } from '../context/AppContext';
import Timer from '../components/dashboard/Timer';
import StudyStatsCard from '../components/dashboard/StudyStatsCard';
import UpcomingTasks from '../components/dashboard/UpcomingTasks';
import RecommendationCard from '../components/dashboard/RecommendationCard';
import StudySessionCard from '../components/dashboard/StudySessionCard';
import { analyzeStudyPatterns } from '../utils/aiRecommendations';
import { PlusCircle } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { subjects, tasks, studySessions, stats, toggleTaskCompletion, updateStudySession } = useAppContext();
  
  // Get upcoming study sessions (today and tomorrow)
  const getUpcomingSessions = () => {
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(23, 59, 59, 999);
    
    return studySessions
      .filter(session => {
        const sessionDate = new Date(session.date);
        return !session.completed && sessionDate <= tomorrow;
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(0, 3); // Limit to 3 sessions
  };
  
  const upcomingSessions = getUpcomingSessions();
  
  // Recommendations from AI
  const recommendations = analyzeStudyPatterns(studySessions, subjects);

  // Complete a study session
  const completeSession = (sessionId: string) => {
    const session = studySessions.find(s => s.id === sessionId);
    if (session) {
      updateStudySession({ ...session, completed: true });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-6">
        {/* Left column (2/3 width on desktop) */}
        <div className="w-full md:w-2/3 space-y-6">
          {/* Welcome banner */}
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl shadow-lg p-6">
            <h1 className="text-2xl font-bold mb-2">Welcome back!</h1>
            <p className="opacity-90 mb-6">Your study journey continues. Here's what you need to focus on today.</p>
            
            <button className="bg-white text-blue-700 hover:bg-blue-50 px-4 py-2 rounded-lg font-medium transition-colors flex items-center">
              <PlusCircle size={18} className="mr-2" />
              Generate Study Plan
            </button>
          </div>
          
          {/* Stats card */}
          <StudyStatsCard stats={stats} />
          
          {/* Upcoming tasks */}
          <UpcomingTasks tasks={tasks} onToggleComplete={toggleTaskCompletion} />
        </div>
        
        {/* Right column (1/3 width on desktop) */}
        <div className="w-full md:w-1/3 space-y-6">
          {/* Timer */}
          <Timer />
          
          {/* AI Recommendations */}
          <RecommendationCard recommendations={recommendations} />
        </div>
      </div>
      
      {/* Upcoming Study Sessions */}
      <div>
        <h2 className="text-xl font-bold text-gray-800 mb-4">Upcoming Study Sessions</h2>
        {upcomingSessions.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {upcomingSessions.map(session => {
              const subject = subjects.find(s => s.id === session.subjectId);
              if (!subject) return null;
              
              return (
                <StudySessionCard
                  key={session.id}
                  session={session}
                  subject={subject}
                  onComplete={() => completeSession(session.id)}
                />
              );
            })}
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow-sm p-6 text-center">
            <p className="text-gray-500 mb-3">No upcoming study sessions</p>
            <button className="text-blue-600 hover:text-blue-800 font-medium">
              Schedule a study session
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;