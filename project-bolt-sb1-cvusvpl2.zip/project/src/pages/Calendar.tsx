import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { ChevronLeft, ChevronRight, Plus } from 'lucide-react';

const Calendar: React.FC = () => {
  const { subjects, studySessions, updateStudySession } = useAppContext();
  const [currentMonth, setCurrentMonth] = useState(new Date());
  
  // Navigation functions
  const prevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
  };
  
  const nextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
  };
  
  // Helper function to get days in month
  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };
  
  // Helper function to get day of week for first day of month
  const getFirstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };
  
  // Generate month name
  const monthName = currentMonth.toLocaleString('default', { month: 'long', year: 'numeric' });
  
  // Generate days of week
  const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  
  // Generate calendar days
  const generateCalendarDays = () => {
    const daysInMonth = getDaysInMonth(currentMonth);
    const firstDayOfMonth = getFirstDayOfMonth(currentMonth);
    const days = [];
    
    // Add empty days for beginning of month
    for (let i = 0; i < firstDayOfMonth; i++) {
      days.push(<div key={`empty-${i}`} className="h-24 bg-gray-50"></div>);
    }
    
    // Add days of month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
      
      // Get sessions for this day
      const daySessions = studySessions.filter(session => {
        const sessionDate = new Date(session.date);
        return (
          sessionDate.getDate() === day &&
          sessionDate.getMonth() === currentMonth.getMonth() &&
          sessionDate.getFullYear() === currentMonth.getFullYear()
        );
      });
      
      // Check if today
      const isToday = 
        date.getDate() === new Date().getDate() &&
        date.getMonth() === new Date().getMonth() &&
        date.getFullYear() === new Date().getFullYear();
      
      days.push(
        <div 
          key={day} 
          className={`h-24 p-1 border border-gray-100 relative ${isToday ? 'bg-blue-50' : 'bg-white'}`}
        >
          <div className={`text-sm font-medium ${isToday ? 'text-blue-700' : 'text-gray-700'} m-1`}>
            {day}
          </div>
          
          <div className="overflow-y-auto max-h-16">
            {daySessions.map(session => {
              const subject = subjects.find(s => s.id === session.subjectId);
              if (!subject) return null;
              
              return (
                <div
                  key={session.id}
                  className={`text-xs p-1 mb-1 rounded truncate ${
                    session.completed ? 'opacity-50' : 'cursor-pointer hover:opacity-80'
                  }`}
                  style={{ 
                    backgroundColor: `${subject.color}20`,
                    color: subject.color,
                    borderLeft: `3px solid ${subject.color}`
                  }}
                  onClick={() => {
                    if (!session.completed) {
                      updateStudySession({ ...session, completed: true });
                    }
                  }}
                >
                  {subject.name} ({session.duration}m)
                </div>
              );
            })}
          </div>
          
          {/* Add button */}
          <div className="absolute bottom-1 right-1">
            <button className="p-1 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-500">
              <Plus size={14} />
            </button>
          </div>
        </div>
      );
    }
    
    return days;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Study Calendar</h1>
        
        <div className="flex items-center">
          <button 
            onClick={prevMonth}
            className="p-2 rounded hover:bg-gray-100"
          >
            <ChevronLeft size={20} />
          </button>
          
          <h2 className="text-lg font-semibold mx-4 min-w-20 text-center">{monthName}</h2>
          
          <button 
            onClick={nextMonth}
            className="p-2 rounded hover:bg-gray-100"
          >
            <ChevronRight size={20} />
          </button>
        </div>
        
        <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center">
          <Plus size={16} className="mr-1" />
          Add Session
        </button>
      </div>
      
      {/* Color legend */}
      <div className="flex flex-wrap gap-2 mb-4">
        {subjects.map(subject => (
          <div key={subject.id} className="flex items-center">
            <div 
              className="w-3 h-3 rounded-full mr-1" 
              style={{ backgroundColor: subject.color }}
            ></div>
            <span className="text-xs text-gray-600">{subject.name}</span>
          </div>
        ))}
      </div>
      
      {/* Calendar grid */}
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        {/* Days of week */}
        <div className="grid grid-cols-7 bg-gray-50 border-b">
          {daysOfWeek.map(day => (
            <div key={day} className="py-2 text-center text-sm font-medium text-gray-600">
              {day}
            </div>
          ))}
        </div>
        
        {/* Calendar days */}
        <div className="grid grid-cols-7">
          {generateCalendarDays()}
        </div>
      </div>
    </div>
  );
};

export default Calendar;