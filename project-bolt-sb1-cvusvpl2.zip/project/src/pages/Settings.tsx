import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { Bell, Clock, HelpCircle, Save } from 'lucide-react';

const Settings: React.FC = () => {
  const { userPreferences, updateUserPreferences } = useAppContext();
  const [preferences, setPreferences] = useState({ ...userPreferences });
  const [isSaved, setIsSaved] = useState(false);
  
  const handleChange = (field: keyof typeof preferences, value: any) => {
    setPreferences(prev => ({ ...prev, [field]: value }));
    setIsSaved(false);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserPreferences(preferences);
    setIsSaved(true);
    
    // Remove success message after 3 seconds
    setTimeout(() => {
      setIsSaved(false);
    }, 3000);
  };

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Settings</h1>
      
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <form onSubmit={handleSubmit}>
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-lg font-bold text-gray-800 mb-4">Study Preferences</h2>
            
            {/* Daily study goal */}
            <div className="mb-4">
              <label htmlFor="dailyStudyGoal" className="block text-sm font-medium text-gray-700 mb-1">
                Daily Study Goal (minutes)
              </label>
              <div className="flex items-center">
                <input
                  type="number"
                  id="dailyStudyGoal"
                  min="15"
                  step="15"
                  value={preferences.dailyStudyGoal}
                  onChange={(e) => handleChange('dailyStudyGoal', parseInt(e.target.value))}
                  className="w-full max-w-xs p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                />
                <div className="ml-2 text-sm text-gray-500">
                  {Math.floor(preferences.dailyStudyGoal / 60)}h {preferences.dailyStudyGoal % 60}m
                </div>
              </div>
              <p className="mt-1 text-sm text-gray-500">
                This is the amount of time you want to study each day.
              </p>
            </div>
            
            {/* Preferred study time */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Preferred Study Time
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {(['morning', 'afternoon', 'evening', 'night'] as const).map((time) => (
                  <button
                    key={time}
                    type="button"
                    onClick={() => handleChange('preferredStudyTime', time)}
                    className={`py-2 px-4 text-sm rounded-md transition-colors ${
                      preferences.preferredStudyTime === time
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {time.charAt(0).toUpperCase() + time.slice(1)}
                  </button>
                ))}
              </div>
              <p className="mt-1 text-sm text-gray-500">
                This helps AI generate better study schedules for you.
              </p>
            </div>
          </div>
          
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
              <Clock size={18} className="mr-2 text-blue-600" />
              Timer Settings
            </h2>
            
            {/* Break frequency */}
            <div className="mb-4">
              <label htmlFor="breakFrequency" className="block text-sm font-medium text-gray-700 mb-1">
                Study Session Length (minutes)
              </label>
              <div className="flex items-center">
                <input
                  type="range"
                  id="breakFrequency"
                  min="15"
                  max="60"
                  step="5"
                  value={preferences.breakFrequency}
                  onChange={(e) => handleChange('breakFrequency', parseInt(e.target.value))}
                  className="w-full max-w-xs"
                />
                <span className="ml-2 text-sm font-medium text-gray-700">{preferences.breakFrequency} min</span>
              </div>
              <p className="mt-1 text-sm text-gray-500">
                Study session length before a break (Pomodoro technique).
              </p>
            </div>
            
            {/* Break duration */}
            <div className="mb-4">
              <label htmlFor="breakDuration" className="block text-sm font-medium text-gray-700 mb-1">
                Break Duration (minutes)
              </label>
              <div className="flex items-center">
                <input
                  type="range"
                  id="breakDuration"
                  min="1"
                  max="15"
                  value={preferences.breakDuration}
                  onChange={(e) => handleChange('breakDuration', parseInt(e.target.value))}
                  className="w-full max-w-xs"
                />
                <span className="ml-2 text-sm font-medium text-gray-700">{preferences.breakDuration} min</span>
              </div>
              <p className="mt-1 text-sm text-gray-500">
                How long your breaks should be between study sessions.
              </p>
            </div>
          </div>
          
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
              <Bell size={18} className="mr-2 text-blue-600" />
              Notifications
            </h2>
            
            <div className="flex items-center mb-4">
              <input
                type="checkbox"
                id="notifications"
                checked={preferences.notifications}
                onChange={(e) => handleChange('notifications', e.target.checked)}
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor="notifications" className="ml-2 block text-sm text-gray-700">
                Enable notifications
              </label>
            </div>
            <p className="text-sm text-gray-500">
              Receive reminders for upcoming study sessions and tasks.
            </p>
          </div>
          
          <div className="p-6 bg-gray-50 flex items-center justify-between">
            <div>
              {isSaved && (
                <span className="text-green-600 text-sm flex items-center">
                  <span className="bg-green-100 p-1 rounded-full mr-1">✓</span>
                  Settings saved successfully!
                </span>
              )}
            </div>
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center"
            >
              <Save size={16} className="mr-1" />
              Save Settings
            </button>
          </div>
        </form>
      </div>
      
      {/* Help & Support */}
      <div className="mt-8 bg-white rounded-xl shadow-md p-6">
        <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
          <HelpCircle size={18} className="mr-2 text-blue-600" />
          Help & Support
        </h2>
        
        <div className="space-y-4">
          <div>
            <h3 className="font-medium text-gray-800 mb-1">How does AI generate my study plan?</h3>
            <p className="text-sm text-gray-600">
              Our AI analyzes your subjects, their difficulty levels, task priorities, and due dates to create an optimized study schedule. It also considers your preferred study times and learning patterns.
            </p>
          </div>
          
          <div>
            <h3 className="font-medium text-gray-800 mb-1">What is the Pomodoro technique?</h3>
            <p className="text-sm text-gray-600">
              The Pomodoro technique involves studying for a set amount of time (e.g., 25 minutes) followed by a short break (e.g., 5 minutes). This cycle helps maintain focus and prevent burnout during study sessions.
            </p>
          </div>
          
          <div>
            <h3 className="font-medium text-gray-800 mb-1">How can I get the most out of StudyAI?</h3>
            <p className="text-sm text-gray-600">
              For best results, regularly update your tasks, complete your study sessions, and provide feedback on AI recommendations. The more you use the system, the better it will understand your study patterns and provide personalized advice.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;