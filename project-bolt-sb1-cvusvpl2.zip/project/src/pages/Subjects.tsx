import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { PlusCircle, Pencil, Trash2, BookOpen, FileText, X } from 'lucide-react';
import PDFUploader from '../components/subjects/PDFUploader';

const Subjects: React.FC = () => {
  const { subjects, addSubject, updateSubject, deleteSubject, tasks, studySessions } = useAppContext();
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [showUploader, setShowUploader] = useState(false);
  const [newSubject, setNewSubject] = useState({
    name: '',
    color: '#3B82F6',
    difficulty: 3,
    priority: 2
  });

  // Function to get statistics for a subject
  const getSubjectStats = (subjectId: string) => {
    const subjectTasks = tasks.filter(task => task.subjectId === subjectId);
    const subjectSessions = studySessions.filter(session => session.subjectId === subjectId);
    
    const totalTasks = subjectTasks.length;
    const completedTasks = subjectTasks.filter(task => task.completed).length;
    const taskCompletion = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
    
    const totalSessions = subjectSessions.length;
    const completedSessions = subjectSessions.filter(session => session.completed).length;
    
    const totalStudyTime = subjectSessions.reduce((total, session) => {
      return session.completed ? total + session.duration : total;
    }, 0);
    
    return {
      totalTasks,
      completedTasks,
      taskCompletion,
      totalSessions,
      completedSessions,
      totalStudyTime
    };
  };

  // Function to format study time
  const formatStudyTime = (minutes: number) => {
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins > 0 ? `${mins}m` : ''}`;
  };

  // Function to handle form submission for new/edited subject
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isEditing) {
      updateSubject({ id: isEditing, ...newSubject });
      setIsEditing(null);
    } else {
      addSubject(newSubject);
      setIsAdding(false);
    }
    
    // Reset form
    setNewSubject({
      name: '',
      color: '#3B82F6',
      difficulty: 3,
      priority: 2
    });
  };

  // Function to start editing a subject
  const startEditing = (subject: typeof subjects[0]) => {
    setNewSubject({
      name: subject.name,
      color: subject.color,
      difficulty: subject.difficulty,
      priority: subject.priority
    });
    setIsEditing(subject.id);
    setIsAdding(false);
  };

  // Function to handle subject deletion
  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this subject? All associated tasks and study sessions will also be deleted.')) {
      deleteSubject(id);
    }
  };

  // Handle PDF upload
  const handlePDFUpload = (subjectId: string) => {
    setSelectedSubject(subjectId);
    setShowUploader(true);
  };

  const handleUploadComplete = (file: File, pageCount: number) => {
    if (selectedSubject) {
      const subject = subjects.find(s => s.id === selectedSubject);
      if (subject) {
        const material = {
          id: crypto.randomUUID(),
          name: file.name,
          type: 'pdf' as const,
          size: file.size,
          pageCount,
          uploadedAt: new Date()
        };
        
        updateSubject({
          ...subject,
          materials: [...(subject.materials || []), material]
        });
      }
    }
    setShowUploader(false);
    setSelectedSubject(null);
  };

  // Difficulty levels
  const difficultyLevels = [
    { value: 1, label: 'Very Easy' },
    { value: 2, label: 'Easy' },
    { value: 3, label: 'Medium' },
    { value: 4, label: 'Hard' },
    { value: 5, label: 'Very Hard' }
  ];

  // Priority levels
  const priorityLevels = [
    { value: 1, label: 'Low' },
    { value: 2, label: 'Medium' },
    { value: 3, label: 'High' }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Subjects</h1>
        
        {!isAdding && !isEditing && (
          <button 
            onClick={() => setIsAdding(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center"
          >
            <PlusCircle size={16} className="mr-1" />
            Add Subject
          </button>
        )}
      </div>
      
      {/* Form for adding/editing subject */}
      {(isAdding || isEditing) && (
        <div className="bg-white rounded-xl shadow-md p-6 mb-6">
          <h2 className="text-lg font-bold mb-4">
            {isEditing ? 'Edit Subject' : 'Add New Subject'}
          </h2>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                Subject Name
              </label>
              <input
                type="text"
                id="name"
                value={newSubject.name}
                onChange={(e) => setNewSubject({ ...newSubject, name: e.target.value })}
                className="w-full p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>
            
            <div>
              <label htmlFor="color" className="block text-sm font-medium text-gray-700 mb-1">
                Color
              </label>
              <div className="flex items-center">
                <input
                  type="color"
                  id="color"
                  value={newSubject.color}
                  onChange={(e) => setNewSubject({ ...newSubject, color: e.target.value })}
                  className="w-10 h-10 rounded-md border-0 p-0"
                />
                <input
                  type="text"
                  value={newSubject.color}
                  onChange={(e) => setNewSubject({ ...newSubject, color: e.target.value })}
                  className="ml-2 p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="difficulty" className="block text-sm font-medium text-gray-700 mb-1">
                Difficulty Level
              </label>
              <div className="flex space-x-1">
                {difficultyLevels.map(level => (
                  <button
                    key={level.value}
                    type="button"
                    onClick={() => setNewSubject({ ...newSubject, difficulty: level.value })}
                    className={`flex-1 py-2 px-3 text-sm rounded-md transition-colors ${
                      newSubject.difficulty === level.value
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {level.label}
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <label htmlFor="priority" className="block text-sm font-medium text-gray-700 mb-1">
                Priority Level
              </label>
              <div className="flex space-x-1">
                {priorityLevels.map(level => (
                  <button
                    key={level.value}
                    type="button"
                    onClick={() => setNewSubject({ ...newSubject, priority: level.value })}
                    className={`flex-1 py-2 px-3 text-sm rounded-md transition-colors ${
                      newSubject.priority === level.value
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {level.label}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setIsAdding(false);
                  setIsEditing(null);
                  setNewSubject({
                    name: '',
                    color: '#3B82F6',
                    difficulty: 3,
                    priority: 2
                  });
                }}
                className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
              >
                {isEditing ? 'Update' : 'Add'} Subject
              </button>
            </div>
          </form>
        </div>
      )}

      {/* PDF Uploader Modal */}
      {showUploader && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 max-w-lg w-full mx-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-gray-800">Upload Study Material</h3>
              <button
                onClick={() => {
                  setShowUploader(false);
                  setSelectedSubject(null);
                }}
                className="p-1 hover:bg-gray-100 rounded-full"
              >
                <X size={20} className="text-gray-500" />
              </button>
            </div>
            <PDFUploader
              onUpload={handleUploadComplete}
              onError={(error) => {
                alert(error);
                setShowUploader(false);
                setSelectedSubject(null);
              }}
            />
          </div>
        </div>
      )}
      
      {/* Subjects list */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {subjects.map(subject => {
          const stats = getSubjectStats(subject.id);
          
          return (
            <div key={subject.id} className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-100 hover:shadow-lg transition-all">
              <div className="h-2" style={{ backgroundColor: subject.color }}></div>
              <div className="p-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-lg font-bold flex items-center text-gray-800">
                    <BookOpen size={18} className="mr-2" style={{ color: subject.color }} />
                    {subject.name}
                  </h3>
                  
                  <div className="flex items-center space-x-2">
                    <button 
                      onClick={() => handlePDFUpload(subject.id)}
                      className="p-1.5 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors"
                      title="Upload PDF"
                    >
                      <FileText size={16} />
                    </button>
                    <button 
                      onClick={() => startEditing(subject)}
                      className="p-1.5 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors"
                    >
                      <Pencil size={16} />
                    </button>
                    <button 
                      onClick={() => handleDelete(subject.id)}
                      className="p-1.5 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Difficulty:</span>
                    <span className="font-medium text-gray-800">
                      {difficultyLevels.find(l => l.value === subject.difficulty)?.label}
                    </span>
                  </div>
                  
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Priority:</span>
                    <span className="font-medium text-gray-800">
                      {priorityLevels.find(l => l.value === subject.priority)?.label}
                    </span>
                  </div>
                  
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Tasks:</span>
                    <span className="font-medium text-gray-800">
                      {stats.completedTasks}/{stats.totalTasks} Completed
                    </span>
                  </div>
                  
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Study Time:</span>
                    <span className="font-medium text-gray-800">
                      {formatStudyTime(stats.totalStudyTime)}
                    </span>
                  </div>

                  {/* Study Materials */}
                  {subject.materials && subject.materials.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-gray-100">
                      <h4 className="text-sm font-medium text-gray-700 mb-2">Study Materials</h4>
                      <div className="space-y-2">
                        {subject.materials.map(material => (
                          <div
                            key={material.id}
                            className="flex items-center justify-between text-sm bg-gray-50 p-2 rounded"
                          >
                            <div className="flex items-center">
                              <FileText size={14} className="text-gray-500 mr-2" />
                              <span className="text-gray-700">{material.name}</span>
                            </div>
                            <span className="text-gray-500">
                              {material.pageCount} pages
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {/* Task completion progress bar */}
                  <div>
                    <div className="flex justify-between text-xs text-gray-500 mb-1">
                      <span>Task Completion</span>
                      <span>{Math.round(stats.taskCompletion)}%</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div 
                        className="h-full rounded-full" 
                        style={{ 
                          width: `${stats.taskCompletion}%`,
                          backgroundColor: subject.color 
                        }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      
      {subjects.length === 0 && !isAdding && (
        <div className="bg-white rounded-xl shadow-md p-8 text-center">
          <BookOpen size={40} className="mx-auto text-gray-400 mb-3" />
          <h3 className="text-lg font-medium text-gray-800 mb-2">No Subjects Yet</h3>
          <p className="text-gray-500 mb-4">Add your first subject to start organizing your studies.</p>
          <button 
            onClick={() => setIsAdding(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            <PlusCircle size={16} className="inline mr-1" />
            Add Subject
          </button>
        </div>
      )}
    </div>
  );
};

export default Subjects;