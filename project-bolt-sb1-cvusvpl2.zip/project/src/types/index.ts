export interface Subject {
  id: string;
  name: string;
  color: string;
  difficulty: number; // 1-5 scale
  priority: number; // 1-3 scale
  materials?: StudyMaterial[];
}

export interface StudyMaterial {
  id: string;
  name: string;
  type: 'pdf';
  size: number;
  pageCount: number;
  uploadedAt: Date;
}

export interface Task {
  id: string;
  title: string;
  description?: string;
  completed: boolean;
  subjectId: string;
  dueDate?: Date;
  estimatedTime?: number; // in minutes
  priority: number; // 1-3 scale
}

export interface StudySession {
  id: string;
  subjectId: string;
  date: Date;
  duration: number; // in minutes
  completed: boolean;
  notes?: string;
}

export interface StudyStats {
  totalStudyTime: number; // in minutes
  sessionsCompleted: number;
  subjectBreakdown: Record<string, number>; // subjectId: minutes
  weeklyProgress: Record<string, number>; // ISO week: minutes
}

export interface UserPreferences {
  dailyStudyGoal: number; // in minutes
  preferredStudyTime: "morning" | "afternoon" | "evening" | "night";
  breakFrequency: number; // in minutes
  breakDuration: number; // in minutes
  notifications: boolean;
}